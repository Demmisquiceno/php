<?php

$valor1 = $_POST['valor1'];
$valor2 = $_POST['valor2'];

$total = $valor1 * $valor2;

echo "La distancia rrecorrica es   " .$total;

?>