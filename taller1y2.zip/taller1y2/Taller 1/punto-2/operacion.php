<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <main>

        <h1>PHP</h1>
        <form action="operacion-2.php" method="post">

            <label for="valor1">Nombre del estudiante</label><input name="Nombre" type="text" value="">
            <label for="valor2">Asignatura</label><input name="Materia" type="text" value="">
            <label for="valor3">Nota 1</label><input name="valor3" type="text" value="">
            <label for="valor4">Nota 2</label><input name="valor4" type="text" value="">
            <label for="valor5">Nota 3</label><input name="valor5" type="text" value="">
            <input type="submit" name="enviar" value="enviar" >
        </form>
    </main>