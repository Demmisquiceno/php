<?php

$numero1 = $_POST['valor1'];
$numero2 = $_POST['valor2'];
?>