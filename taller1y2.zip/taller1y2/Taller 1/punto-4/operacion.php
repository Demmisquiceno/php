<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action=" Practica.php" method="post">
        <label for="valor">numero de horas laboradas en el mes (HL)</label><input  name ="valor1" type="text"  value="">

        <label for="valor2">valor por hora (VH)</label><input  name ="valor2" type="text"  value="">

        <input type="submit" name="enviar" value="enviar"  >

    </form>
    
</body>
</html>