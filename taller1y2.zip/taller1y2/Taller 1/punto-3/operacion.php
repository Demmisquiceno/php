<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <main>

        <h1>PHP</h1>
        <form action="operacion-3.php" method="post">
            <label for="valor">Velocidad Constante (m/s)</label><input name="valor1" type="text" value="">
            <label for="valor1">Tiempo (Sg)</label><input name="valor2" type="text" value="">
            <input type="submit" name="enviar" value="enviar" >
        </form>
    </main>
</body>
</html>