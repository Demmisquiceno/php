<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <main>

        <h1>PHP</h1>
        <form action="operacion-8.php" method="post">

            <label for="valor1">Digita tu sexo</label>
            <select name="sexo" type="text" value="" >
                        <option value="F" name="">Femenino</option>
                        <option value="M" selected>Masculino</option>
                </select>

                    <label for="valor1">Edad</label><input name="edad" type="text" value="">
                    <input type="submit" name="enviar" value="enviar" >
           
        </form>
       

        
    </main>
</body>
</html>
